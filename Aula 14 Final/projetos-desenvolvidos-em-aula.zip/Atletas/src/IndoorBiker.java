
public class IndoorBiker extends Ciclista {

	@Override
	public void pedaladas(int giros) {
		// TODO Auto-generated method stub

	}

}
