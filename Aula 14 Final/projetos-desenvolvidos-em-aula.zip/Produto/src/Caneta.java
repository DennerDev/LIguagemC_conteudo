
public class Caneta extends Produto{

}
