
public class Filme2 extends Produto2 {

}
