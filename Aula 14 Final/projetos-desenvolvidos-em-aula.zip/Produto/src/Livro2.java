
public class Livro2 extends Produto2 {

}
