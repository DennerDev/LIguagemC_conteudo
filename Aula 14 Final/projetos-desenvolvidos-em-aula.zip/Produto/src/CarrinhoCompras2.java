import java.util.ArrayList;
import java.util.List;

public class CarrinhoCompras2 {
	List<Produto2> listProd = new ArrayList<Produto2>();
	
	public void adicionar(Produto2 prod) {
		listProd.add(prod);
	}
}
