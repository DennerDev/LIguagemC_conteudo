
public class Caderno extends Produto{

}
